const http = require("http");
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const ROOT = __dirname;
const WEB = path.join(ROOT, "web");
const DATA = path.join(ROOT, "data");
const REPORTS = path.join(ROOT, "reports");
const SIMULATION = path.join(ROOT, "simulation");

const PORT = Number(process.env.PORT || 8080);

function readJSON(file, fallback = []) {
    try {
        return JSON.parse(fs.readFileSync(file, "utf8"));
    } catch {
        return fallback;
    }
}

function send(res, status, body, type = "text/html; charset=utf-8") {
    res.writeHead(status, {
        "Content-Type": type,
        "Cache-Control": "no-store"
    });
    res.end(body);
}

function writeJSON(file, data) {
    const temp = file + ".tmp";
    fs.writeFileSync(
        temp,
        JSON.stringify(data, null, 2),
        "utf8"
    );
    fs.renameSync(temp, file);
}

function readRequestBody(req) {
    return new Promise((resolve, reject) => {
        let body = "";

        req.on("data", chunk => {
            body += chunk;

            if (body.length > 1024 * 1024) {
                reject(new Error("Request body too large"));
                req.destroy();
            }
        });

        req.on("end", () => {
            if (!body.trim()) {
                resolve({});
                return;
            }

            try {
                resolve(JSON.parse(body));
            } catch {
                reject(new Error("Invalid JSON"));
            }
        });

        req.on("error", reject);
    });
}

function audit(action, details = {}) {
    const file = path.join(DATA, "audit.json");
    const logs = readJSON(file);

    logs.push({
        action,
        time: new Date().toISOString(),
        ...details
    });

    writeJSON(file, logs);
}

function nextId(records) {
    if (!records.length) return 1;

    return Math.max(
        ...records.map(x => Number(x.id) || 0)
    ) + 1;
}

function json(res, data, status = 200) {
    send(res, status, JSON.stringify(data, null, 2), "application/json; charset=utf-8");
}

function safeName(name) {
    return path.basename(String(name || ""));
}

function reportFile(name) {
    const allowed = [
        "pharmacy_report.pdf",
        "pharmacy_report.txt",
        "pharmacy_report.tex",
        "snap.txt"
    ];

    const clean = safeName(name);

    if (!allowed.includes(clean)) {
        return null;
    }

    return path.join(REPORTS, clean);
}

function runPython(script) {
    try {
        return execFileSync(
            "python",
            [path.join(SIMULATION, script)],
            {
                cwd: ROOT,
                encoding: "utf8",
                timeout: 120000
            }
        );
    } catch (e) {
        return e.stdout || e.stderr || String(e);
    }
}

function compileReport() {
    const clean = path.join(ROOT, "compiletex-clean.sh");
    const compile = path.join(ROOT, "compiletex1.sh");

    if (!fs.existsSync(clean)) {
        return {
            ok: false,
            message: "compiletex-clean.sh not found"
        };
    }

    if (!fs.existsSync(compile)) {
        return {
            ok: false,
            message: "compiletex1.sh not found"
        };
    }

    try {
        execFileSync("bash", [clean], {
            cwd: ROOT,
            encoding: "utf8",
            timeout: 120000
        });

        execFileSync("bash", [compile], {
            cwd: ROOT,
            encoding: "utf8",
            timeout: 120000
        });

        const pdf = path.join(REPORTS, "pharmacy_report.pdf");

        if (!fs.existsSync(pdf)) {
            return {
                ok: false,
                message: "Compilation finished but PDF was not created"
            };
        }

        return {
            ok: true,
            message: "PDF generated successfully",
            file: "pharmacy_report.pdf"
        };

    } catch (e) {
        return {
            ok: false,
            message: e.stdout || e.stderr || e.message || String(e)
        };
    }
}

function summary() {
    const medicines = readJSON(path.join(DATA, "medicines.json"));
    const sales = readJSON(path.join(DATA, "sales.json"));

    const revenue = sales.reduce(
        (sum, s) => sum + Number(s.total || 0),
        0
    );

    const inventoryValue = medicines.reduce(
        (sum, m) =>
            sum +
            Number(m.price || 0) *
            Number(m.quantity || 0),
        0
    );

    const lowStock = medicines.filter(
        m => Number(m.quantity || 0) <= 10
    ).length;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const ninetyDays = new Date(today);
    ninetyDays.setDate(ninetyDays.getDate() + 90);

    const expired = medicines.filter(m => {
        if (!m.expiry) return false;
        const expiry = new Date(m.expiry + "T00:00:00");
        return expiry < today;
    }).length;

    const expiringSoon = medicines.filter(m => {
        if (!m.expiry) return false;
        const expiry = new Date(m.expiry + "T00:00:00");
        return expiry >= today && expiry <= ninetyDays;
    }).length;

    return {
        medicines: medicines.length,
        sales: sales.length,
        revenue,
        inventoryValue,
        lowStock,
        expired,
        expiringSoon
    };
}

function reportCenter() {
    const files = [
        "pharmacy_report.pdf",
        "pharmacy_report.txt",
        "pharmacy_report.tex",
        "snap.txt"
    ];

    return {
        files: files.filter(
            f => fs.existsSync(path.join(REPORTS, f))
        ),
        primary: "pharmacy_report.pdf"
    };
}

function serveStatic(req, res) {
    let pathname = decodeURIComponent(
        new URL(req.url, `http://${req.headers.host}`).pathname
    );

    if (pathname === "/") {
        pathname = "/index.html";
    }

    const relative = pathname.replace(/^\/+/, "");
    const file = path.resolve(WEB, relative);

    if (!file.startsWith(path.resolve(WEB))) {
        return send(res, 403, "Forbidden");
    }

    if (!fs.existsSync(file)) {
        return send(res, 404, "Not Found");
    }

    const ext = path.extname(file).toLowerCase();

    const types = {
        ".html": "text/html; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".txt": "text/plain; charset=utf-8"
    };

    send(
        res,
        200,
        fs.readFileSync(file),
        types[ext] || "application/octet-stream"
    );
}

const server = http.createServer((req, res) => {

    const url = new URL(
        req.url,
        `http://${req.headers.host}`
    );



if (req.method === "GET" && url.pathname === "/api/health") {

    const medicines =
        readJSON(path.join(DATA, "medicines.json"));

    const sales =
        readJSON(path.join(DATA, "sales.json"));

    const suppliers =
        readJSON(path.join(DATA, "suppliers.json"));

    const purchases =
        readJSON(path.join(DATA, "purchases.json"));

    const audit =
        readJSON(path.join(DATA, "audit.json"));

    return json(res, {
        system: "PHARMACY MANAGEMENT SYSTEM",
        version: "V13",
        status: "ONLINE",
        database: "JSON",
        medicines: medicines.length,
        sales: sales.length,
        suppliers: suppliers.length,
        purchases: purchases.length,
        auditEntries: audit.length,
        timestamp: new Date().toISOString()
    });
}

    // --------------------------------------------------------
    // SUMMARY
    // --------------------------------------------------------

    if (req.method === "GET" && url.pathname === "/api/summary") {
        return json(res, summary());
    }

    // --------------------------------------------------------
    // REPORT CENTER
    // --------------------------------------------------------

    if (req.method === "GET" && url.pathname === "/api/reports") {
        return json(res, reportCenter());
    }

    // --------------------------------------------------------
    // COMPILE REPORT
    // --------------------------------------------------------

    if (
        req.method === "POST" &&
        url.pathname === "/api/reports/compile"
    ) {
        return json(res, compileReport());
    }

    // --------------------------------------------------------
    // SERVE REPORT FILES
    // --------------------------------------------------------

    if (
        req.method === "GET" &&
        url.pathname === "/reports/file"
    ) {
        const file = reportFile(url.searchParams.get("name"));

        if (!file) {
            return send(res, 400, "Invalid report file");
        }

        if (!fs.existsSync(file)) {
            return send(res, 404, "Report file not found");
        }

        const ext = path.extname(file).toLowerCase();

        let type = "application/octet-stream";

        if (ext === ".pdf") {
            type = "application/pdf";
        } else if (ext === ".txt" || ext === ".tex") {
            type = "text/plain; charset=utf-8";
        }

        return send(res, 200, fs.readFileSync(file), type);
    }


    // --------------------------------------------------------
    // SUPPLIER API
    // --------------------------------------------------------

    if (req.method === "GET" && url.pathname === "/api/suppliers") {
        return json(
            res,
            readJSON(path.join(DATA, "suppliers.json"))
        );
    }

    if (req.method === "POST" && url.pathname === "/api/suppliers") {
        readRequestBody(req)
            .then(body => {

                const name = String(body.name || "").trim();
                const phone = String(body.phone || "").trim();
                const address = String(body.address || "").trim();

                if (!name) {
                    return json(
                        res,
                        { error: "Supplier name is required" },
                        400
                    );
                }

                const file = path.join(DATA, "suppliers.json");
                const suppliers = readJSON(file);

                const duplicate = suppliers.find(
                    s =>
                        String(s.name || "").toLowerCase() ===
                        name.toLowerCase()
                );

                if (duplicate) {
                    return json(
                        res,
                        {
                            error: "Supplier already exists",
                            supplier: duplicate
                        },
                        409
                    );
                }

                const supplier = {
                    id: nextId(suppliers),
                    name,
                    phone,
                    address,
                    createdAt: new Date().toISOString()
                };

                suppliers.push(supplier);
                writeJSON(file, suppliers);

                audit("SUPPLIER_ADD", {
                    supplierId: supplier.id,
                    supplierName: supplier.name
                });

                return json(res, supplier, 201);
            })
            .catch(error => {
                return json(
                    res,
                    { error: error.message },
                    400
                );
            });

        return;
    }

    // --------------------------------------------------------
    // PURCHASE API
    // --------------------------------------------------------

    if (req.method === "GET" && url.pathname === "/api/purchases") {
        return json(
            res,
            readJSON(path.join(DATA, "purchases.json"))
        );
    }

    if (req.method === "POST" && url.pathname === "/api/purchases") {
        readRequestBody(req)
            .then(body => {

                const supplierId = Number(body.supplierId);
                const medicineId = Number(body.medicineId);
                const quantity = Number(body.quantity);
                const unitCost = Number(body.unitCost || 0);

                if (!Number.isInteger(supplierId) || supplierId <= 0) {
                    return json(
                        res,
                        { error: "Valid supplierId is required" },
                        400
                    );
                }

                if (!Number.isInteger(medicineId) || medicineId <= 0) {
                    return json(
                        res,
                        { error: "Valid medicineId is required" },
                        400
                    );
                }

                if (!Number.isFinite(quantity) || quantity <= 0) {
                    return json(
                        res,
                        { error: "Quantity must be greater than zero" },
                        400
                    );
                }

                if (!Number.isFinite(unitCost) || unitCost < 0) {
                    return json(
                        res,
                        { error: "Unit cost cannot be negative" },
                        400
                    );
                }

                const suppliers = readJSON(
                    path.join(DATA, "suppliers.json")
                );

                const medicines = readJSON(
                    path.join(DATA, "medicines.json")
                );

                const supplier = suppliers.find(
                    s => Number(s.id) === supplierId
                );

                if (!supplier) {
                    return json(
                        res,
                        { error: "Supplier not found" },
                        404
                    );
                }

                const medicine = medicines.find(
                    m => Number(m.id) === medicineId
                );

                if (!medicine) {
                    return json(
                        res,
                        { error: "Medicine not found" },
                        404
                    );
                }

                const file = path.join(DATA, "purchases.json");
                const purchases = readJSON(file);

                const purchase = {
                    id: nextId(purchases),
                    supplierId,
                    supplierName: supplier.name,
                    medicineId,
                    medicineName: medicine.name,
                    quantity,
                    unitCost,
                    totalCost: quantity * unitCost,
                    date: body.date || new Date().toISOString(),
                    batchNumber: String(body.batchNumber || "").trim(),
                    expiry: String(body.expiry || "").trim(),
                    createdAt: new Date().toISOString()
                };

                purchases.push(purchase);
                writeJSON(file, purchases);

                audit("PURCHASE_ADD", {
                    purchaseId: purchase.id,
                    supplierId,
                    medicineId,
                    quantity
                });

                return json(res, purchase, 201);
            })
            .catch(error => {
                return json(
                    res,
                    { error: error.message },
                    400
                );
            });

        return;
    }

    // --------------------------------------------------------
    // INVENTORY STOCK-IN
    // --------------------------------------------------------

    if (
        req.method === "POST" &&
        url.pathname === "/api/inventory/stock-in"
    ) {
        readRequestBody(req)
            .then(body => {

                const supplierId = Number(body.supplierId);
                const medicineId = Number(body.medicineId);
                const quantity = Number(body.quantity);
                const unitCost = Number(body.unitCost || 0);

                if (!Number.isInteger(supplierId) || supplierId <= 0) {
                    return json(
                        res,
                        { error: "Valid supplierId is required" },
                        400
                    );
                }

                if (!Number.isInteger(medicineId) || medicineId <= 0) {
                    return json(
                        res,
                        { error: "Valid medicineId is required" },
                        400
                    );
                }

                if (!Number.isFinite(quantity) || quantity <= 0) {
                    return json(
                        res,
                        { error: "Quantity must be greater than zero" },
                        400
                    );
                }

                if (!Number.isFinite(unitCost) || unitCost < 0) {
                    return json(
                        res,
                        { error: "Unit cost cannot be negative" },
                        400
                    );
                }

                const supplierFile =
                    path.join(DATA, "suppliers.json");

                const medicineFile =
                    path.join(DATA, "medicines.json");

                const purchaseFile =
                    path.join(DATA, "purchases.json");

                const suppliers = readJSON(supplierFile);
                const medicines = readJSON(medicineFile);
                const purchases = readJSON(purchaseFile);

                const supplier = suppliers.find(
                    s => Number(s.id) === supplierId
                );

                if (!supplier) {
                    return json(
                        res,
                        { error: "Supplier not found" },
                        404
                    );
                }

                const medicineIndex = medicines.findIndex(
                    m => Number(m.id) === medicineId
                );

                if (medicineIndex === -1) {
                    return json(
                        res,
                        { error: "Medicine not found" },
                        404
                    );
                }

                const medicine = medicines[medicineIndex];

                const oldQuantity =
                    Number(medicine.quantity || 0);

                const newQuantity =
                    oldQuantity + quantity;

                const purchase = {
                    id: nextId(purchases),
                    supplierId,
                    supplierName: supplier.name,
                    medicineId,
                    medicineName: medicine.name,
                    quantity,
                    unitCost,
                    totalCost: quantity * unitCost,
                    date: body.date || new Date().toISOString(),
                    batchNumber: String(body.batchNumber || "").trim(),
                    expiry: String(body.expiry || "").trim(),
                    createdAt: new Date().toISOString()
                };

                medicine.quantity = newQuantity;

                if (purchase.expiry) {
                    medicine.expiry = purchase.expiry;
                }

                purchases.push(purchase);

                writeJSON(purchaseFile, purchases);
                writeJSON(medicineFile, medicines);

                audit("STOCK_IN", {
                    purchaseId: purchase.id,
                    supplierId,
                    supplierName: supplier.name,
                    medicineId,
                    medicineName: medicine.name,
                    quantity,
                    oldQuantity,
                    newQuantity
                });

                return json(
                    res,
                    {
                        success: true,
                        purchase,
                        stock: {
                            medicineId,
                            medicineName: medicine.name,
                            oldQuantity,
                            quantityAdded: quantity,
                            newQuantity
                        }
                    },
                    201
                );
            })
            .catch(error => {
                return json(
                    res,
                    { error: error.message },
                    400
                );
            });

        return;
    }
    // --------------------------------------------------------
    // INVENTORY STOCK-OUT
    // --------------------------------------------------------

    if (
        req.method === "POST" &&
        url.pathname === "/api/inventory/stock-out"
    ) {
        readRequestBody(req)
            .then(body => {

                const medicineId = Number(body.medicineId);
                const quantity = Number(body.quantity);

                if (!Number.isInteger(medicineId) || medicineId <= 0) {
                    return json(
                        res,
                        { error: "Valid medicineId is required" },
                        400
                    );
                }

                if (!Number.isFinite(quantity) || quantity <= 0) {
                    return json(
                        res,
                        { error: "Quantity must be greater than zero" },
                        400
                    );
                }

                const medicineFile =
                    path.join(DATA, "medicines.json");

                const salesFile =
                    path.join(DATA, "sales.json");

                const medicines = readJSON(medicineFile);
                const sales = readJSON(salesFile);

                const medicineIndex = medicines.findIndex(
                    m => Number(m.id) === medicineId
                );

                if (medicineIndex === -1) {
                    return json(
                        res,
                        { error: "Medicine not found" },
                        404
                    );
                }

                const medicine = medicines[medicineIndex];

                const oldQuantity =
                    Number(medicine.quantity || 0);

                if (oldQuantity < quantity) {
                    return json(
                        res,
                        {
                            error: "Insufficient stock",
                            available: oldQuantity,
                            requested: quantity
                        },
                        400
                    );
                }

                const newQuantity =
                    oldQuantity - quantity;

                const sale = {
                    medicine: medicine.name,
                    qty: quantity,
                    total: quantity * Number(medicine.price || 0),
                    date: body.date || new Date().toISOString()
                };

                medicine.quantity = newQuantity;

                sales.push(sale);

                writeJSON(medicineFile, medicines);
                writeJSON(salesFile, sales);

                audit("STOCK_OUT", {
                    medicineId,
                    medicineName: medicine.name,
                    quantity,
                    oldQuantity,
                    newQuantity
                });

                return json(
                    res,
                    {
                        success: true,
                        sale,
                        stock: {
                            medicineId,
                            medicineName: medicine.name,
                            oldQuantity,
                            quantityRemoved: quantity,
                            newQuantity
                        }
                    },
                    201
                );
            })
            .catch(error => {
                return json(
                    res,
                    { error: error.message },
                    400
                );
            });

        return;
    }



    // --------------------------------------------------------
    // EXISTING / CORE API
    // --------------------------------------------------------

    if (req.method === "GET" && url.pathname === "/api/medicines") {
        return json(
            res,
            readJSON(path.join(DATA, "medicines.json"))
        );
    }

    if (req.method === "GET" && url.pathname === "/api/sales") {
        return json(
            res,
            readJSON(path.join(DATA, "sales.json"))
        );
    }


if (req.method === "GET" && url.pathname === "/api/cash") {

    const sales =
        readJSON(path.join(DATA, "sales.json"));

    const revenue =
        sales.reduce(
            (sum, sale) =>
                sum + Number(sale.total || 0),
            0
        );

    return json(res, {
        date: new Date().toISOString().slice(0, 10),
        sales: sales.length,
        revenue
    });
}
if (req.method === "GET" && url.pathname === "/api/sas") {

    const files =
        fs.readdirSync(path.join(ROOT, "exports"))
            .filter(f => f.toLowerCase().endsWith(".sas"));

    return json(res, {
        files,
        directory: "exports"
    });
}
if (req.method === "GET" && url.pathname === "/api/alerts") {

    const medicines = readJSON(
        path.join(DATA, "medicines.json")
    );

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const ninetyDays = new Date(today);
    ninetyDays.setDate(
        ninetyDays.getDate() + 90
    );

    const lowStock =
        medicines.filter(
            m => Number(m.quantity || 0) <= 10
        );

    const expired =
        medicines.filter(m => {

            if (!m.expiry)
                return false;

            const expiry =
                new Date(m.expiry + "T00:00:00");

            return expiry < today;
        });

    const expiringSoon =
        medicines.filter(m => {

            if (!m.expiry)
                return false;

            const expiry =
                new Date(m.expiry + "T00:00:00");

            return (
                expiry >= today &&
                expiry <= ninetyDays
            );
        });

    return json(
        res,
        {
            lowStock,
            expired,
            expiringSoon
        }
    );
}

if (req.method === "GET" && url.pathname === "/api/snapshot") {

    const medicines =
        readJSON(path.join(DATA, "medicines.json"));

    const sales =
        readJSON(path.join(DATA, "sales.json"));

    const snapshot =
`Meds:${medicines.length}
Sales:${sales.length}
Revenue:${sales.reduce(
    (sum, sale) => sum + Number(sale.total || 0),
    0
)}`;

    const file =
        path.join(REPORTS, "snap.txt");

    fs.writeFileSync(file, snapshot);

    return send(
        res,
        200,
        snapshot,
        "text/plain; charset=utf-8"
    );
}

    if (req.method === "GET" && url.pathname === "/api/forecast") {
        return send(
            res,
            200,
            runPython("forecast.py"),
            "text/plain; charset=utf-8"
        );
    }

    if (req.method === "GET" && url.pathname === "/api/monte-carlo") {
        return send(
            res,
            200,
            runPython("inventory_sim.py"),
            "text/plain; charset=utf-8"
        );
    }

    if (req.method === "GET" && url.pathname === "/api/reorder-point") {
        return send(
            res,
            200,
            runPython("reorder_point.py"),
            "text/plain; charset=utf-8"
        );
    }

    if (req.method === "GET" && url.pathname === "/api/safety-stock") {
        return send(
            res,
            200,
            runPython("safety_stock.py"),
            "text/plain; charset=utf-8"
        );
    }

    if (req.method === "GET" && url.pathname === "/api/expiry-risk") {
        return send(
            res,
            200,
            runPython("expiry_risk.py"),
            "text/plain; charset=utf-8"
        );
    }

    if (req.method === "GET" && url.pathname === "/api/abc") {
        return send(
            res,
            200,
            runPython("abc_analysis.py"),
            "text/plain; charset=utf-8"
        );
    }

    if (req.method === "GET" && url.pathname === "/api/eoq") {
        return send(
            res,
            200,
            runPython("eoq.py"),
            "text/plain; charset=utf-8"
        );
    }

    if (req.method === "GET" && url.pathname === "/api/ai") {
        return send(
            res,
            200,
            runPython("ai_dashboard.py"),
            "text/plain; charset=utf-8"
        );
    }



    // --------------------------------------------------------
    // DECISION MODELS
    // --------------------------------------------------------

    if (
        req.method === "GET" &&
        url.pathname.startsWith("/api/model/")
    ) {

        const name =
            url.pathname
                .replace("/api/model/", "")
                .replace(/^\/+|\/+$/g, "");

        const models = {
            "forecast": "forecast.py",
            "monte-carlo": "inventory_sim.py",
            "monteCarlo": "inventory_sim.py",
            "reorder-point": "reorder_point.py",
            "reorderPoint": "reorder_point.py",
            
"safety-stock": "safety_stock.py",
"safetyStock": "safety_stock.py",
           
		"expiry-risk": "expiry_risk.py",

"expiry-risk": "expiry_risk.py",
"expiryRisk": "expiry_risk.py",

            "abc": "abc_analysis.py",
            "eoq": "eoq.py",
            "ai": "ai_dashboard.py"
        };

        const script = models[name];

        if (!script) {
            return json(
                res,
                {
                    error: "Unknown decision model",
                    model: name
                },
                404
            );
        }

        const output =
            runPython(script);

        return json(res, {
            model: name,
            script,
            output
        });
    }

    // --------------------------------------------------------
    // STATIC WEB
    // --------------------------------------------------------

    return serveStatic(req, res);
});

server.listen(PORT, () => {
    console.log("");
    console.log("============================================================");
    console.log(" PHARMACY V12 WEB PLATFORM");
    console.log("============================================================");
    console.log(` http://127.0.0.1:${PORT}`);
    console.log("");
});
