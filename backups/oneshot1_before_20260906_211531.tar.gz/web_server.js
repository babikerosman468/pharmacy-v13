const fs = require("fs");
const http = require("http");
const path = require("path");
const { exec } = require("child_process");

const ROOT = __dirname;
const WEB = path.join(ROOT, "web");

const DB = {
  MED: path.join(ROOT, "data/medicines.json"),
  SALES: path.join(ROOT, "data/sales.json"),
  AUDIT: path.join(ROOT, "data/audit.json")
};

function load(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return [];
  }
}

function save(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function audit(action) {
  const a = load(DB.AUDIT);
  a.push({
    action,
    time: new Date().toISOString()
  });
  save(DB.AUDIT, a);
}

function summary() {
  const medicines = load(DB.MED);
  const sales = load(DB.SALES);

  const revenue = sales.reduce(
    (sum, x) => sum + Number(x.total || 0),
    0
  );

  const inventoryValue = medicines.reduce(
    (sum, x) =>
      sum +
      Number(x.price || 0) * Number(x.quantity || 0),
    0
  );

  const lowStock = medicines.filter(
    x => Number(x.quantity || 0) <= 10
  );

  const expired = medicines.filter(
    x =>
      x.expiry &&
      !isNaN(new Date(x.expiry)) &&
      new Date(x.expiry) < new Date()
  );

  const expiringSoon = medicines.filter(x => {
    if (!x.expiry || isNaN(new Date(x.expiry))) return false;

    const d = new Date(x.expiry);
    const now = new Date();
    const future = new Date();
    future.setDate(future.getDate() + 90);

    return d >= now && d <= future;
  });

  return {
    medicines: medicines.length,
    sales: sales.length,
    revenue,
    inventoryValue,
    lowStock: lowStock.length,
    expired: expired.length,
    expiringSoon: expiringSoon.length
  };
}

function json(res, data, status = 200) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });

  res.end(JSON.stringify(data));
}

function body(req) {
  return new Promise((resolve, reject) => {
    let data = "";

    req.on("data", chunk => {
      data += chunk;
    });

    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (e) {
        reject(e);
      }
    });
  });
}

function safeFile(file) {
  const allowed = [
    "index.html",
    "style.css",
    "app.js"
  ];

  return allowed.includes(file)
    ? path.join(WEB, file)
    : null;
}

const server = http.createServer(async (req, res) => {

  try {

    // --------------------------------------------------------
    // API: SUMMARY
    // --------------------------------------------------------

    if (req.method === "GET" && req.url === "/api/summary") {
      return json(res, summary());
    }

    // --------------------------------------------------------
    // API: MEDICINES
    // --------------------------------------------------------

    if (
      req.method === "GET" &&
      req.url.startsWith("/api/medicines")
    ) {

      const medicines = load(DB.MED);

      const url = new URL(
        req.url,
        "http://localhost:8080"
      );

      const q = (
        url.searchParams.get("q") || ""
      ).toLowerCase();

      const result = q
        ? medicines.filter(x =>
            String(x.name || "")
              .toLowerCase()
              .includes(q)
          )
        : medicines;

      return json(res, result);
    }

    // --------------------------------------------------------
    // API: SALES
    // --------------------------------------------------------

    if (req.method === "GET" && req.url === "/api/sales") {
      return json(res, load(DB.SALES));
    }

    // --------------------------------------------------------
    // API: ALERTS
    // --------------------------------------------------------

    if (req.method === "GET" && req.url === "/api/alerts") {

      const medicines = load(DB.MED);

      const lowStock = medicines.filter(
        x => Number(x.quantity || 0) <= 10
      );

      const expired = medicines.filter(
        x =>
          x.expiry &&
          !isNaN(new Date(x.expiry)) &&
          new Date(x.expiry) < new Date()
      );

      return json(res, {
        lowStock,
        expired
      });
    }

    // --------------------------------------------------------
    // API: SELL
    // --------------------------------------------------------

    if (req.method === "POST" && req.url === "/api/sell") {

      const data = await body(req);

      const name = String(data.name || "").trim();
      const qty = Number(data.qty);

      if (!name || !Number.isFinite(qty) || qty <= 0) {
        return json(
          res,
          { error: "Invalid medicine or quantity" },
          400
        );
      }

      const medicines = load(DB.MED);

      const medicine = medicines.find(
        x =>
          String(x.name || "").toLowerCase() ===
          name.toLowerCase()
      );

      if (!medicine) {
        return json(
          res,
          { error: "Medicine not found" },
          404
        );
      }

      if (Number(medicine.quantity) < qty) {
        return json(
          res,
          { error: "Insufficient stock" },
          400
        );
      }

      medicine.quantity -= qty;

      save(DB.MED, medicines);

      const sales = load(DB.SALES);

      const sale = {
        medicine: medicine.name,
        qty,
        total: qty * Number(medicine.price || 0),
        date: new Date().toISOString()
      };

      sales.push(sale);

      save(DB.SALES, sales);

      audit("WEB SALE");

      return json(res, {
        success: true,
        sale
      });
    }

    // --------------------------------------------------------
    // API: ADD MEDICINE
    // --------------------------------------------------------

    if (
      req.method === "POST" &&
      req.url === "/api/medicines"
    ) {

      const data = await body(req);

      const name = String(data.name || "").trim();
      const quantity = Number(data.quantity);
      const price = Number(data.price);
      const expiry = String(data.expiry || "").trim();

      if (
        !name ||
        !Number.isFinite(quantity) ||
        !Number.isFinite(price)
      ) {
        return json(
          res,
          { error: "Invalid medicine data" },
          400
        );
      }

      const medicines = load(DB.MED);

      const medicine = {
        id: Date.now(),
        name,
        quantity,
        price,
        expiry
      };

      medicines.push(medicine);

      save(DB.MED, medicines);

      audit("WEB ADD MEDICINE");

      return json(res, {
        success: true,
        medicine
      });
    }

    // --------------------------------------------------------
    // API: PYTHON FORECAST
    // --------------------------------------------------------

    if (
      req.method === "GET" &&
      req.url === "/api/forecast"
    ) {

      exec(
        "python simulation/forecast.py",
        {
          cwd: ROOT,
          timeout: 30000
        },
        (error, stdout, stderr) => {

          if (error) {
            return json(res, {
              success: false,
              error: stderr || error.message
            });
          }

          json(res, {
            success: true,
            output: stdout
          });
        }
      );

      return;
    }

    // --------------------------------------------------------
    // API: ABC ANALYSIS
    // --------------------------------------------------------

    if (
      req.method === "GET" &&
      req.url === "/api/abc"
    ) {

      exec(
        "python simulation/abc_analysis.py",
        {
          cwd: ROOT,
          timeout: 30000
        },
        (error, stdout, stderr) => {

          if (error) {
            return json(res, {
              success: false,
              error: stderr || error.message
            });
          }

          json(res, {
            success: true,
            output: stdout
          });
        }
      );

      return;
    }

    // --------------------------------------------------------
    // API: EOQ
    // --------------------------------------------------------

    if (
      req.method === "GET" &&
      req.url === "/api/eoq"
    ) {

      exec(
        "python simulation/eoq.py",
        {
          cwd: ROOT,
          timeout: 30000
        },
        (error, stdout, stderr) => {

          if (error) {
            return json(res, {
              success: false,
              error: stderr || error.message
            });
          }

          json(res, {
            success: true,
            output: stdout
          });
        }
      );

      return;
    }

    // --------------------------------------------------------
    // API: AI DASHBOARD
    // --------------------------------------------------------

    if (
      req.method === "GET" &&
      req.url === "/api/ai"
    ) {

      exec(
        "python simulation/ai_dashboard.py",
        {
          cwd: ROOT,
          timeout: 30000
        },
        (error, stdout, stderr) => {

          if (error) {
            return json(res, {
              success: false,
              error: stderr || error.message
            });
          }

          json(res, {
            success: true,
            output: stdout
          });
        }
      );

      return;
    }

    // --------------------------------------------------------
    // STATIC FILES
    // --------------------------------------------------------

    let file = req.url === "/"
      ? "index.html"
      : req.url.substring(1).split("?")[0];

    const full = safeFile(file);

    if (!full || !fs.existsSync(full)) {
      res.writeHead(404);
      return res.end("Not Found");
    }

    const ext = path.extname(full);

    const types = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "application/javascript; charset=utf-8"
    };

    res.writeHead(200, {
      "Content-Type":
        types[ext] || "text/plain; charset=utf-8"
    });

    res.end(fs.readFileSync(full));

  } catch (e) {

    console.error(e);

    json(
      res,
      {
        error: e.message
      },
      500
    );
  }

});

server.listen(8080, "0.0.0.0", () => {

  console.log("");
  console.log("================================================");
  console.log(" PHARMACY V12 WEB PLATFORM");
  console.log("================================================");
  console.log("Local:   http://127.0.0.1:8080");
  console.log("Network: http://0.0.0.0:8080");
  console.log("================================================");
  console.log("");
});
