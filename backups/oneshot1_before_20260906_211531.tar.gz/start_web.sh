#!/data/data/com.termux/files/usr/bin/bash

cd "$HOME/pharmacy-v12"

echo
echo "Starting Pharmacy V12 Web Platform..."
echo
echo "Open:"
echo "http://127.0.0.1:8080"
echo

node web_server.js
