async function api(url, options = {}) {

  const response = await fetch(url, options);

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || "Request failed");
  }

  return data;
}


function show(id) {

  document
    .querySelectorAll(".page")
    .forEach(x => x.classList.add("hidden"));

  const page = document.getElementById(id);

  if (page) page.classList.remove("hidden");

  if (id === "dashboard") loadDashboard();
  if (id === "medicines") loadMedicines();
  if (id === "sales") loadSales();
  if (id === "inventory") loadInventory();
  if (id === "alerts") loadAlerts();
}


async function loadDashboard() {

  try {

    const d = await api("/api/summary");

    document.getElementById("medCount").textContent =
      d.medicines;

    document.getElementById("salesCount").textContent =
      d.sales;

    document.getElementById("revenue").textContent =
      d.revenue.toLocaleString();

    document.getElementById("inventoryValue").textContent =
      d.inventoryValue.toLocaleString();

    document.getElementById("lowStock").textContent =
      d.lowStock;

    document.getElementById("expired").textContent =
      d.expired;

    document.getElementById("expiringSoon").textContent =
      d.expiringSoon;

  } catch (e) {

    alert(e.message);
  }
}


async function loadMedicines() {

  const q =
    document.getElementById("search")?.value || "";

  const medicines =
    await api(
      "/api/medicines?q=" +
      encodeURIComponent(q)
    );

  let html = `
  <table>
  <tr>
    <th>Name</th>
    <th>Quantity</th>
    <th>Price</th>
    <th>Expiry</th>
  </tr>
  `;

  medicines.forEach(m => {

    html += `
    <tr>
      <td>${escapeHtml(m.name)}</td>
      <td>${m.quantity}</td>
      <td>${m.price}</td>
      <td>${escapeHtml(m.expiry || "")}</td>
    </tr>
    `;
  });

  html += "</table>";

  document.getElementById(
    "medicineTable"
  ).innerHTML = html;
}


async function loadInventory() {

  const medicines =
    await api("/api/medicines");

  let html = `
  <table>
  <tr>
    <th>Medicine</th>
    <th>Quantity</th>
    <th>Unit Price</th>
    <th>Inventory Value</th>
  </tr>
  `;

  medicines.forEach(m => {

    const value =
      Number(m.quantity || 0) *
      Number(m.price || 0);

    html += `
    <tr>
      <td>${escapeHtml(m.name)}</td>
      <td>${m.quantity}</td>
      <td>${m.price}</td>
      <td>${value.toLocaleString()}</td>
    </tr>
    `;
  });

  html += "</table>";

  document.getElementById(
    "inventoryTable"
  ).innerHTML = html;
}


async function loadSales() {

  const sales =
    await api("/api/sales");

  let html = `
  <table>
  <tr>
    <th>Medicine</th>
    <th>Qty</th>
    <th>Total</th>
    <th>Date</th>
  </tr>
  `;

  sales.slice().reverse().forEach(s => {

    html += `
    <tr>
      <td>${escapeHtml(s.medicine)}</td>
      <td>${s.qty}</td>
      <td>${s.total}</td>
      <td>${escapeHtml(s.date)}</td>
    </tr>
    `;
  });

  html += "</table>";

  document.getElementById(
    "salesTable"
  ).innerHTML = html;
}


async function loadAlerts() {

  const d =
    await api("/api/alerts");

  document.getElementById(
    "lowStockTable"
  ).innerHTML =
    makeTable(d.lowStock);

  document.getElementById(
    "expiredTable"
  ).innerHTML =
    makeTable(d.expired);
}


function makeTable(items) {

  if (!items.length) {
    return "<p>None</p>";
  }

  let html = `
  <table>
  <tr>
    <th>Medicine</th>
    <th>Quantity</th>
    <th>Expiry</th>
  </tr>
  `;

  items.forEach(x => {

    html += `
    <tr>
      <td>${escapeHtml(x.name)}</td>
      <td>${x.quantity}</td>
      <td>${escapeHtml(x.expiry || "")}</td>
    </tr>
    `;
  });

  return html + "</table>";
}


async function sellMedicine() {

  const name =
    document.getElementById("saleName").value;

  const qty =
    Number(
      document.getElementById("saleQty").value
    );

  try {

    const result =
      await api(
        "/api/sell",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            name,
            qty
          })
        }
      );

    alert(
      "Sale completed: " +
      result.sale.total
    );

    document.getElementById(
      "saleName"
    ).value = "";

    document.getElementById(
      "saleQty"
    ).value = "";

    loadSales();
    loadDashboard();

  } catch (e) {

    alert(e.message);
  }
}


async function addMedicine() {

  const name =
    prompt("Medicine name:");

  if (!name) return;

  const quantity =
    Number(prompt("Quantity:", "0"));

  const price =
    Number(prompt("Price:", "0"));

  const expiry =
    prompt(
      "Expiry date YYYY-MM-DD:",
      ""
    );

  try {

    await api(
      "/api/medicines",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name,
          quantity,
          price,
          expiry
        })
      }
    );

    alert("Medicine added.");

    loadMedicines();
    loadDashboard();

  } catch (e) {

    alert(e.message);
  }
}


async function runModel(model) {

  show("model");

  document.getElementById(
    "modelTitle"
  ).textContent =
    model.toUpperCase();

  document.getElementById(
    "modelOutput"
  ).textContent =
    "Running " + model + "...";

  try {

    const result =
      await api("/api/" + model);

    document.getElementById(
      "modelOutput"
    ).textContent =
      result.output ||
      JSON.stringify(result, null, 2);

  } catch (e) {

    document.getElementById(
      "modelOutput"
    ).textContent =
      "ERROR\n\n" + e.message;
  }
}


function escapeHtml(value) {

  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


loadDashboard();
