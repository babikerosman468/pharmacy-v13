const http = require("http");
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const APP = __dirname;

const DB = {
  MED: path.join(APP, "data/medicines.json"),
  SALES: path.join(APP, "data/sales.json"),
  SUPPLIERS: path.join(APP, "data/suppliers.json"),
  PURCHASES: path.join(APP, "data/purchases.json"),
  AUDIT: path.join(APP, "data/audit.json")
};

function load(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return [];
  }
}

function save(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function json(res, data, code = 200) {
  res.writeHead(code, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*"
  });
  res.end(JSON.stringify(data));
}

function body(req) {
  return new Promise((resolve, reject) => {
    let b = "";
    req.on("data", x => b += x);
    req.on("end", () => {
      try {
        resolve(b ? JSON.parse(b) : {});
      } catch (e) {
        reject(e);
      }
    });
  });
}

function runPython(script) {
  try {
    return execSync(
      `python "${path.join(APP, "simulation", script)}"`,
      { encoding: "utf8", timeout: 120000 }
    );
  } catch (e) {
    return "ERROR: " + (e.stdout || e.message);
  }
}

function summary() {
  const meds = load(DB.MED);
  const sales = load(DB.SALES);

  const revenue = sales.reduce(
    (a, b) => a + Number(b.total || 0), 0
  );

  const inventoryValue = meds.reduce(
    (a, b) =>
      a + Number(b.quantity || 0) * Number(b.price || 0),
    0
  );

  const lowStock = meds.filter(
    m => Number(m.quantity || 0) <= 10
  );

  const now = new Date();

  const expired = meds.filter(m =>
    m.expiry && new Date(m.expiry) < now
  );

  const soon = meds.filter(m => {
    if (!m.expiry) return false;
    const d = new Date(m.expiry);
    const days = (d - now) / 86400000;
    return days >= 0 && days <= 30;
  });

  return {
    medicines: meds.length,
    sales: sales.length,
    revenue,
    inventoryValue,
    lowStock: lowStock.length,
    expired: expired.length,
    expiringSoon: soon.length
  };
}

async function router(req, res) {

  const url = new URL(req.url, "http://localhost");

  // ----------------------------------------------------------
  // CORE
  // ----------------------------------------------------------

  if (url.pathname === "/api/summary") {
    return json(res, summary());
  }

  if (url.pathname === "/api/medicines") {
    const meds = load(DB.MED);
    const q = (url.searchParams.get("q") || "").toLowerCase();

    return json(
      res,
      meds.filter(m =>
        String(m.name || "").toLowerCase().includes(q)
      )
    );
  }

  if (url.pathname === "/api/sales") {
    return json(res, load(DB.SALES));
  }

  if (url.pathname === "/api/alerts") {

    const meds = load(DB.MED);
    const now = new Date();

    return json(res, {
      lowStock: meds.filter(m => Number(m.quantity || 0) <= 10),

      expired: meds.filter(m =>
        m.expiry && new Date(m.expiry) < now
      ),

      expiringSoon: meds.filter(m => {
        if (!m.expiry) return false;
        const d = new Date(m.expiry);
        const days = (d - now) / 86400000;
        return days >= 0 && days <= 30;
      })
    });
  }

  // ----------------------------------------------------------
  // ADD MEDICINE
  // ----------------------------------------------------------

  if (req.method === "POST" &&
      url.pathname === "/api/medicines") {

    const data = await body(req);

    const meds = load(DB.MED);

    const med = {
      id: Date.now(),
      name: data.name,
      quantity: Number(data.quantity || 0),
      price: Number(data.price || 0),
      expiry: data.expiry || ""
    };

    meds.push(med);
    save(DB.MED, meds);

    return json(res, {
      success: true,
      medicine: med
    });
  }

  // ----------------------------------------------------------
  // SELL
  // ----------------------------------------------------------

  if (req.method === "POST" &&
      url.pathname === "/api/sell") {

    const data = await body(req);

    const meds = load(DB.MED);
    const sales = load(DB.SALES);

    const med = meds.find(
      m => String(m.name).toLowerCase() ===
           String(data.name).toLowerCase()
    );

    if (!med)
      return json(res, { error: "Medicine not found" }, 404);

    const qty = Number(data.qty || 0);

    if (qty <= 0)
      return json(res, { error: "Invalid quantity" }, 400);

    if (med.quantity < qty)
      return json(res, { error: "Insufficient stock" }, 400);

    med.quantity -= qty;

    const sale = {
      medicine: med.name,
      qty,
      total: qty * Number(med.price || 0),
      date: new Date().toISOString()
    };

    sales.push(sale);

    save(DB.MED, meds);
    save(DB.SALES, sales);

    return json(res, {
      success: true,
      sale
    });
  }

  // ----------------------------------------------------------
  // ANALYTICS
  // ----------------------------------------------------------

  if (url.pathname === "/api/analytics") {
    const meds = load(DB.MED);
    const sales = load(DB.SALES);

    return json(res, {
      medicineCount: meds.length,
      salesCount: sales.length,
      revenue: sales.reduce(
        (a, b) => a + Number(b.total || 0), 0
      ),
      inventoryValue: meds.reduce(
        (a, b) =>
          a + Number(b.quantity || 0) *
              Number(b.price || 0),
        0
      )
    });
  }

  // ----------------------------------------------------------
  // SUPPLIERS
  // ----------------------------------------------------------

  if (url.pathname === "/api/suppliers") {
    return json(res, load(DB.SUPPLIERS));
  }

  // ----------------------------------------------------------
  // PURCHASES
  // ----------------------------------------------------------

  if (url.pathname === "/api/purchases") {
    return json(res, load(DB.PURCHASES));
  }

  // ----------------------------------------------------------
  // DAILY CASH
  // ----------------------------------------------------------

  if (url.pathname === "/api/cash") {

    const sales = load(DB.SALES);

    const today = new Date().toISOString().slice(0, 10);

    const todaysSales = sales.filter(
      s => String(s.date || "").slice(0, 10) === today
    );

    return json(res, {
      date: today,
      sales: todaysSales.length,
      revenue: todaysSales.reduce(
        (a, b) => a + Number(b.total || 0), 0
      )
    });
  }

  // ----------------------------------------------------------
  // INVENTORY VALUATION
  // ----------------------------------------------------------

  if (url.pathname === "/api/inventory-value") {

    const meds = load(DB.MED);

    return json(res, {
      value: meds.reduce(
        (a, b) =>
          a + Number(b.quantity || 0) *
              Number(b.price || 0),
        0
      )
    });
  }

  // ----------------------------------------------------------
  // PYTHON MODELS
  // ----------------------------------------------------------

  const models = {
    "/api/forecast": "forecast.py",
    "/api/monte-carlo": "inventory_sim.py",
    "/api/reorder-point": "reorder_point.py",
    "/api/safety-stock": "safety_stock.py",
    "/api/expiry-risk": "expiry_risk.py",
    "/api/abc": "abc_analysis.py",
    "/api/eoq": "eoq.py",
    "/api/ai": "ai_dashboard.py"
  };

  if (models[url.pathname]) {
    return json(res, {
      model: url.pathname.replace("/api/", ""),
      output: runPython(models[url.pathname])
    });
  }

  // ----------------------------------------------------------
  // SAS
  // ----------------------------------------------------------

  if (url.pathname === "/api/sas") {

    const file = path.join(
      APP,
      "exports",
      "sas_pipeline.sas"
    );

    return json(res, {
      ready: fs.existsSync(file),
      file
    });
  }

  // ----------------------------------------------------------
  // REPORTS
  // ----------------------------------------------------------

  if (url.pathname === "/api/reports") {

    const files = fs.existsSync(path.join(APP, "reports"))
      ? fs.readdirSync(path.join(APP, "reports"))
      : [];

    return json(res, { files });
  }

  // ----------------------------------------------------------
  // SYSTEM HEALTH
  // ----------------------------------------------------------

  if (url.pathname === "/api/health") {

    return json(res, {
      system: "PHARMACY V12",
      status: "ONLINE",
      node: process.version,
      time: new Date().toISOString(),
      database: {
        medicines: fs.existsSync(DB.MED),
        sales: fs.existsSync(DB.SALES),
        suppliers: fs.existsSync(DB.SUPPLIERS),
        purchases: fs.existsSync(DB.PURCHASES)
      }
    });
  }

  // ----------------------------------------------------------
  // DASHBOARD SNAPSHOT
  // ----------------------------------------------------------

  if (url.pathname === "/api/snapshot") {

    const report = JSON.stringify(summary(), null, 2);

    const file = path.join(
      APP,
      "reports",
      "web_snapshot.txt"
    );

    fs.writeFileSync(file, report);

    return json(res, {
      success: true,
      file
    });
  }

  // ----------------------------------------------------------
  // BATCH IMPORT
  // ----------------------------------------------------------

  if (req.method === "POST" &&
      url.pathname === "/api/batch-import") {

    const data = await body(req);

    const meds = load(DB.MED);

    let imported = 0;

    for (const row of data.rows || []) {

      if (!row.name) continue;

      meds.push({
        id: Date.now() + imported,
        name: row.name,
        quantity: Number(row.quantity || 0),
        price: Number(row.price || 0),
        expiry: row.expiry || ""
      });

      imported++;
    }

    save(DB.MED, meds);

    return json(res, {
      success: true,
      imported
    });
  }

  // ----------------------------------------------------------
  // STATIC WEB FILES
  // ----------------------------------------------------------

  let file;

  if (url.pathname === "/")
    file = path.join(APP, "web/index.html");
  else
    file = path.join(APP, "web", url.pathname);

  if (fs.existsSync(file) &&
      fs.statSync(file).isFile()) {

    const ext = path.extname(file);

    const types = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "application/javascript; charset=utf-8"
    };

    res.writeHead(200, {
      "Content-Type":
        types[ext] || "text/plain; charset=utf-8"
    });

    return res.end(fs.readFileSync(file));
  }

  json(res, { error: "Not found" }, 404);
}

const server = http.createServer((req, res) => {
  router(req, res).catch(err => {
    json(res, {
      error: err.message
    }, 500);
  });
});

server.listen(8080, "0.0.0.0", () => {
  console.log("");
  console.log("================================================");
  console.log(" PHARMACY V12 WEB PLATFORM");
  console.log(" http://127.0.0.1:8080");
  console.log("================================================");
});
