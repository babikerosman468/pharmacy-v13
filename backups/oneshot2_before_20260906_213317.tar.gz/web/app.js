async function api(url, options) {

  const r = await fetch(url, options);

  if (!r.ok)
    throw new Error(await r.text());

  return r.json();
}

function esc(x) {

  return String(x ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function show(id) {

  document.querySelectorAll(".page")
    .forEach(x => x.classList.remove("active"));

  document.getElementById(id)
    .classList.add("active");

  if (id === "dashboard")
    loadDashboard();

  if (id === "medicines")
    loadMedicines();

  if (id === "sales")
    loadSales();

  if (id === "inventory")
    loadInventory();

  if (id === "alerts")
    loadAlerts();

  if (id === "analytics")
    loadAnalytics();

  if (id === "suppliers")
    loadSuppliers();

  if (id === "purchases")
    loadPurchases();

  if (id === "cash")
    loadCash();

  if (id === "reports")
    loadReports();

  if (id === "sas")
    loadSAS();

  if (id === "health")
    loadHealth();
}

async function loadDashboard() {

  const d = await api("/api/summary");

  medCount.textContent = d.medicines;
  salesCount.textContent = d.sales;
  revenue.textContent = d.revenue;
  inventoryValue.textContent = d.inventoryValue;
  lowStock.textContent = d.lowStock;
  expired.textContent = d.expired;
  expiringSoon.textContent = d.expiringSoon;
}

async function loadMedicines() {

  const q = medicineSearch.value || "";

  const meds = await api(
    "/api/medicines?q=" + encodeURIComponent(q)
  );

  medicineTable.innerHTML = `
  <table>
  <tr>
    <th>Medicine</th>
    <th>Quantity</th>
    <th>Price</th>
    <th>Expiry</th>
    <th>Action</th>
  </tr>

  ${meds.map(m => `
  <tr>
    <td>${esc(m.name)}</td>
    <td>${m.quantity}</td>
    <td>${m.price}</td>
    <td>${esc(m.expiry)}</td>
    <td>
      <button onclick="sellMedicine('${esc(m.name)}')">
      Sell
      </button>
    </td>
  </tr>
  `).join("")}

  </table>`;
}

async function loadSales() {

  const sales = await api("/api/sales");

  salesTable.innerHTML = `
  <table>
  <tr>
    <th>Date</th>
    <th>Medicine</th>
    <th>Quantity</th>
    <th>Total</th>
  </tr>

  ${sales.map(s => `
  <tr>
    <td>${esc(s.date)}</td>
    <td>${esc(s.medicine)}</td>
    <td>${s.qty}</td>
    <td>${s.total}</td>
  </tr>
  `).join("")}

  </table>`;
}

async function loadInventory() {

  const meds = await api("/api/medicines");

  inventoryTable.innerHTML = `
  <table>
  <tr>
    <th>Medicine</th>
    <th>Stock</th>
    <th>Unit Price</th>
    <th>Value</th>
  </tr>

  ${meds.map(m => `
  <tr>
    <td>${esc(m.name)}</td>
    <td>${m.quantity}</td>
    <td>${m.price}</td>
    <td>${Number(m.quantity) * Number(m.price)}</td>
  </tr>
  `).join("")}

  </table>`;
}

async function loadAlerts() {

  const a = await api("/api/alerts");

  alertsContent.innerHTML = `
  <h3>Low Stock: ${a.lowStock.length}</h3>

  ${a.lowStock.map(m =>
    `<p>⚠ ${esc(m.name)} — ${m.quantity}</p>`
  ).join("")}

  <h3>Expired: ${a.expired.length}</h3>

  ${a.expired.map(m =>
    `<p>🔴 ${esc(m.name)} — ${esc(m.expiry)}</p>`
  ).join("")}

  <h3>Expiring Soon: ${a.expiringSoon.length}</h3>

  ${a.expiringSoon.map(m =>
    `<p>🟠 ${esc(m.name)} — ${esc(m.expiry)}</p>`
  ).join("")}
  `;
}

async function loadAnalytics() {

  const d = await api("/api/analytics");

  analyticsContent.innerHTML = `
  <h3>Medicines: ${d.medicineCount}</h3>
  <h3>Sales: ${d.salesCount}</h3>
  <h3>Revenue: ${d.revenue}</h3>
  <h3>Inventory Value: ${d.inventoryValue}</h3>
  `;
}

async function loadSuppliers() {

  const d = await api("/api/suppliers");

  supplierContent.innerHTML =
    "<pre>" +
    esc(JSON.stringify(d, null, 2)) +
    "</pre>";
}

async function loadPurchases() {

  const d = await api("/api/purchases");

  purchaseContent.innerHTML =
    "<pre>" +
    esc(JSON.stringify(d, null, 2)) +
    "</pre>";
}

async function loadCash() {

  const d = await api("/api/cash");

  cashContent.innerHTML = `
  <h3>Date: ${d.date}</h3>
  <h3>Sales: ${d.sales}</h3>
  <h3>Revenue: ${d.revenue}</h3>
  `;
}

async function loadReports() {

  const d = await api("/api/reports");

  reportsContent.innerHTML =
    "<pre>" +
    esc(JSON.stringify(d, null, 2)) +
    "</pre>";
}

async function loadSAS() {

  const d = await api("/api/sas");

  sasContent.innerHTML =
    "<pre>" +
    esc(JSON.stringify(d, null, 2)) +
    "</pre>";
}

async function loadHealth() {

  const d = await api("/api/health");

  healthContent.innerHTML =
    "<pre>" +
    esc(JSON.stringify(d, null, 2)) +
    "</pre>";
}

async function model(name) {

  show("model");

  modelTitle.textContent =
    name.toUpperCase();

  modelOutput.textContent =
    "Running " + name + "...\n";

  try {

    const d = await api("/api/" + name);

    modelOutput.textContent = d.output;

  } catch (e) {

    modelOutput.textContent =
      "ERROR\n" + e.message;
  }
}

async function addMedicine() {

  const name = prompt("Medicine name:");

  if (!name) return;

  const quantity =
    prompt("Quantity:", "0");

  const price =
    prompt("Price:", "0");

  const expiry =
    prompt("Expiry YYYY-MM-DD:", "");

  const r = await api("/api/medicines", {

    method: "POST",

    headers: {
      "Content-Type": "application/json"
    },

    body: JSON.stringify({
      name,
      quantity,
      price,
      expiry
    })
  });

  alert(
    r.success
      ? "Medicine added successfully"
      : "Error"
  );

  loadDashboard();
  loadMedicines();
}

async function sellMedicine(name) {

  if (!name)
    name = prompt("Medicine name:");

  if (!name) return;

  const qty =
    prompt("Quantity to sell:", "1");

  if (!qty) return;

  const r = await api("/api/sell", {

    method: "POST",

    headers: {
      "Content-Type": "application/json"
    },

    body: JSON.stringify({
      name,
      qty
    })
  });

  if (r.error) {

    alert(r.error);
    return;
  }

  alert(
    "Sale completed\nTotal: " +
    r.sale.total
  );

  loadDashboard();
  loadMedicines();
}

async function snapshot() {

  const r = await api("/api/snapshot");

  alert(
    r.success
      ? "Dashboard snapshot created"
      : "Snapshot failed"
  );
}

loadDashboard();
