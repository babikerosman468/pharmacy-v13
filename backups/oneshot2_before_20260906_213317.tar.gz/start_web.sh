#!/data/data/com.termux/files/usr/bin/bash

cd "$HOME/pharmacy-v12"

echo "============================================================"
echo " PHARMACY V12 WEB PLATFORM"
echo "============================================================"
echo "URL: http://127.0.0.1:8080"
echo ""
echo "Press Ctrl+C to stop the web server."
echo ""

node web_server.js
